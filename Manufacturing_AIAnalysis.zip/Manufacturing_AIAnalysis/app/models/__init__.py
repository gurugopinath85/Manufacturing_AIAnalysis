"""Data models for the Manufacturing AI Analysis application."""

from .schema_models import (
    DataType,
    ColumnInfo,
    TableSchema,
    TableRelationship,
    DatabaseSchema,
    FileUploadResponse,
    SchemaExtractionRequest,
    SchemaExtractionResponse,
    QueryRequest,
    QueryResult,
    ChatMessage,
    ChatResponse
)

from .decision_models import (
    PriorityLevel,
    RecommendationReason,
    ProductRecommendation,
    ProductionPlan,
    RecommendationRequest,
    RecommendationResponse,
    AnalyticsInsight,
    AnalyticsReport,
    OptimizationObjective,
    OptimizationConstraint,
    OptimizationRequest,
    OptimizationResult
)

__all__ = [
    # Schema models
    "DataType",
    "ColumnInfo", 
    "TableSchema",
    "TableRelationship",
    "DatabaseSchema",
    "FileUploadResponse",
    "SchemaExtractionRequest",
    "SchemaExtractionResponse",
    "QueryRequest",
    "QueryResult",
    "ChatMessage",
    "ChatResponse",
    
    # Decision models
    "PriorityLevel",
    "RecommendationReason", 
    "ProductRecommendation",
    "ProductionPlan",
    "RecommendationRequest",
    "RecommendationResponse",
    "AnalyticsInsight",
    "AnalyticsReport",
    "OptimizationObjective",
    "OptimizationConstraint",
    "OptimizationRequest",
    "OptimizationResult"
]