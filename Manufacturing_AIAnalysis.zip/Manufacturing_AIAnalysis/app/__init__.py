"""
Manufacturing AI Analysis Application

A production-quality AI-powered manufacturing decision assistant.
"""

__version__ = "1.0.0"
__author__ = "Manufacturing AI Team"
__description__ = "AI-powered manufacturing decision assistant for optimized production planning"